---
library_name: peft
license: other
base_model: EleutherAI/polyglot-ko-1.3b
tags:
- llama-factory
- lora
- generated_from_trainer
model-index:
- name: finetuned_model
  results: []
---

<!-- This model card has been generated automatically according to the information the Trainer had access to. You
should probably proofread and complete it, then remove this comment. -->

# finetuned_model

This model is a fine-tuned version of [EleutherAI/polyglot-ko-1.3b](https://huggingface.co/EleutherAI/polyglot-ko-1.3b) on the restaurant dataset.
It achieves the following results on the evaluation set:
- Loss: 5.3570

## Model description

More information needed

## Intended uses & limitations

More information needed

## Training and evaluation data

More information needed

## Training procedure

### Training hyperparameters

The following hyperparameters were used during training:
- learning_rate: 0.0002
- train_batch_size: 1
- eval_batch_size: 1
- seed: 42
- gradient_accumulation_steps: 8
- total_train_batch_size: 8
- optimizer: Adam with betas=(0.9,0.999) and epsilon=1e-08
- lr_scheduler_type: cosine
- lr_scheduler_warmup_ratio: 0.1
- lr_scheduler_warmup_steps: 10
- num_epochs: 10
- mixed_precision_training: Native AMP

### Training results

| Training Loss | Epoch  | Step | Validation Loss |
|:-------------:|:------:|:----:|:---------------:|
| No log        | 0.6154 | 1    | 6.6158          |
| No log        | 1.8462 | 3    | 6.5826          |
| No log        | 2.4615 | 4    | 6.5178          |
| No log        | 3.6923 | 6    | 6.2774          |
| No log        | 4.9231 | 8    | 5.9029          |
| No log        | 5.5385 | 9    | 5.6545          |
| 6.1874        | 6.1538 | 10   | 5.3570          |


### Framework versions

- PEFT 0.12.0
- Transformers 4.45.2
- Pytorch 2.4.0+cu121
- Datasets 2.21.0
- Tokenizers 0.20.3